<?php 

namespace AppBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;

use AppBundle\Entity\events;



class EventsController extends Controller {

	/**
	*@Route("/index", name="index_event")
	*/
	public function indexAction(Request $request) {

		$item = $this->getDoctrine()
					->getRepository('AppBundle:events')
					->findAll();

		return $this->render("Events/index.html.twig", array(
			"item" => $item
		));
	}


	/**
	*@Route("/Events/event/{id}", name="event_page")
	*/

	public function eventAction($id){
		$items = $this->getDoctrine()->getManager();
		$item = $items->getRepository('AppBundle:events')->find($id);

		return $this->render("/Events/event.html.twig", array(
			"event" => $item
		));
	}

	/**
	*@Route("/Events/delete/{id}", name="delete_event")
	*/
	public function deleteAction($id){
		$items = $this->getDoctrine()->getManager();
		$item = $items->getRepository('AppBundle:events')->find($id);

		$items->remove($item);
		$items->flush();

		return $this->redirectToRoute('index_event');
	}

	/**
	*@Route("/Events/addevent", name="add_event")
	*/
	public function addAction(Request $request){
		$item = new events();

		$form = $this->createFormBuilder($item)
		->add('name', TextType::class, array('attr'=>array('class' => 'form-control', 'style' => 'margin-bottom: 20px')))
		->add('event_date', DateType::class, array('attr'=>array('class' => 'form-control', 'style' => 'margin-bottom: 20px')))
		->add('description', TextType::class, array('attr'=>array('class' => 'form-control', 'style' => 'margin-bottom: 20px')))
		->add('img', TextType::class, array('attr'=>array('class' => 'form-control', 'style' => 'margin-bottom: 20px')))
		->add('capacity', IntegerType::class, array('attr'=>array('class' => 'form-control', 'style' => 'margin-bottom: 20px')))
		->add('email', TextType::class, array('attr'=>array('class' => 'form-control', 'style' => 'margin-bottom: 20px')))
		->add('telnum', TextType::class, array('attr'=>array('class' => 'form-control', 'style' => 'margin-bottom: 20px')))
		->add('address', TextType::class, array('attr'=>array('class' => 'form-control', 'style' => 'margin-bottom: 20px')))
		->add('url', TextType::class, array('attr'=>array('class' => 'form-control', 'style' => 'margin-bottom: 20px')))
		->add('type', ChoiceType::class, array('choices' => array("Rap"=>"Rap", "Techno" => "Techno", "Minimal" => "Minimal", "Rock"=>"Rock"), 'attr'=>array('class' => 'form-control', 'style' => 'margin-bottom:20px')))
		->add('save', SubmitType::class, array('label' => 'Add new Event', 'attr' => array('class' => 'btn btn-primary')))
		->getForm();

		$form->handleRequest($request);

		if($form->isSubmitted() && $form->isValid()) {
			$item = $form->getData();

			$em = $this->getDoctrine()->getManager();
			$em->persist($item);
			$em->flush();

			return $this->redirectToRoute('index_event');
		}

		return $this->render('Events/addevent.html.twig', array(
			'form'=>$form->createView()
		));
	}


	/**
	 *@Route("Events/editevent/{id}", name="edit_event")
	 */

	public function editAction(Request $request, $id){

		$item = $this->getDoctrine()
				->getRepository('AppBundle:events')
				->find($id);

		$form = $this->createFormBuilder($item)
		->add('name', TextType::class, array('attr'=>array('class' => 'form-control', 'style' => 'margin-bottom: 20px')))
		->add('event_date', DateType::class, array('widget' => 'single_text', 'attr'=>array('style' => 'margin-bottom: 20px')))
		->add('description', TextType::class, array('attr'=>array('class' => 'form-control', 'style' => 'margin-bottom: 20px')))
		->add('img', TextType::class, array('attr'=>array('class' => 'form-control', 'style' => 'margin-bottom: 20px')))
		->add('capacity', IntegerType::class, array('attr'=>array('class' => 'form-control', 'style' => 'margin-bottom: 20px')))
		->add('email', TextType::class, array('attr'=>array('class' => 'form-control', 'style' => 'margin-bottom: 20px')))
		->add('telnum', TextType::class, array('attr'=>array('class' => 'form-control', 'style' => 'margin-bottom: 20px')))
		->add('address', TextType::class, array('attr'=>array('class' => 'form-control', 'style' => 'margin-bottom: 20px')))
		->add('url', TextType::class, array('attr'=>array('class' => 'form-control', 'style' => 'margin-bottom: 20px')))
		->add('type', ChoiceType::class, array('choices' => array("Rap"=>"Rap", "Techno" => "Techno", "Minimal" => "Minimal", "Rock"=>"Rock"), 'attr'=>array('class' => 'form-control', 'style' => 'margin-bottom:20px')))
		->add('save', SubmitType::class, array('label' => 'Edit Event', 'attr' => array('class' => 'btn btn-primary')))
		->getForm();

		$form->handleRequest($request);

		if($form->isSubmitted() && $form->isValid()) {
			$item = $form->getData();

			$em = $this->getDoctrine()->getManager();
			$em->persist($item);
			$em->flush();

			return $this->redirectToRoute('index_event');
		}

		return $this->render('Events/addevent.html.twig', array(
			'form'=>$form->createView()
		));		
	}


	/**
	*@Route("Events/sortevent/{type}", name="Sort_event")
	*/

	public function sortAction($type){
		$repository = $this->getDoctrine()->getRepository('AppBundle:events');
		$item = $repository->findByType($type);

		return $this->render('Events/sortevent.html.twig', array(
			'item' => $item
		));
		
	}













}











 ?>