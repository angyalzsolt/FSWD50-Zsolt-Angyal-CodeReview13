-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2018. Dec 01. 13:46
-- Kiszolgáló verziója: 10.1.36-MariaDB
-- PHP verzió: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `cr13_zsolt_angyal_bigevents`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `event_date` datetime NOT NULL,
  `description` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `img` varchar(254) COLLATE utf8_unicode_ci NOT NULL,
  `capacity` int(11) DEFAULT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `telnum` int(11) NOT NULL,
  `address` varchar(254) COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(254) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- A tábla adatainak kiíratása `events`
--

INSERT INTO `events` (`id`, `name`, `event_date`, `description`, `img`, `capacity`, `email`, `telnum`, `address`, `url`, `type`) VALUES
(1, 'Test Name', '2018-11-12 00:00:00', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus sit amet suscipit lorem. Quisque blandit magna laoreet, pellentesque felis in, viverra orci. Pellentesque auctor augue ut purus imperdiet, et scelerisque mauris blandit. Suspendisse scele', 'https://cdn.pixabay.com/photo/2015/05/15/14/50/concert-768722_960_720.jpg', 3000, 'test@email.com', 12444321, 'New York, Test str 32, 9432', 'www.google.com', 'Minimal'),
(2, 'First Edit', '2018-11-28 00:00:00', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus sit amet suscipit lorem. Quisque blandit magna laoreet, pellentesque felis in, viverra orci. Pellentesque auctor augue ut purus imperdiet, et scelerisque mauris blandit. Suspendisse scele', 'https://cdn.pixabay.com/photo/2015/05/15/14/50/concert-768722_960_720.jpg', 231, 'sldjfslkdjfsl@wejwlke', 23234, 'dfsjdfldsjf', 'sdlfjskdfjslj', 'Rap'),
(4, 'John Doe', '2018-11-12 00:00:00', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus sit amet suscipit lorem. Quisque blandit magna laoreet, pellentesque felis in, viverra orci. Pellentesque auctor augue ut purus imperdiet, et scelerisque mauris blandit. Suspendisse scelerisque rhoncus turpis, nec maximus augue tincidunt eget. Morbi accumsan augue a dolor porttitor euismod a a enim.', 'https://cdn.pixabay.com/photo/2015/07/30/17/24/audience-868074_960_720.jpg', 2131, 'sadasd@adas', 12312, 'sdfmskdf kdf lsk  sd', 'dlkéskdf', 'Rock'),
(5, 'Migos', '2023-07-24 00:00:00', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi id fringilla ex. Pellentesque lacus odio, aliquam eget nulla sed, bibendum imperdiet risus. Suspendisse est turpis, tempor in dolor in, efficitur cursus augue. Cras quam orci, porttitor congue nibh et, aliquet pulvinar arcu. Quisque quis eros in velit lobortis pellentesque. Nulla eu urna laoreet, placerat urna at, luctus justo. Morbi auctor, odio eget convallis malesu', 'https://cdn.pixabay.com/photo/2016/11/29/06/17/audience-1867754_960_720.jpg', 5000, 'offset@migos.com', 2147483647, 'New York, NYC, Broadwy 65', 'https://www.lipsum.com/feed/html', 'Rap');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
