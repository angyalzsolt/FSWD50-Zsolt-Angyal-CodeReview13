<?php

/* /Events/event.html.twig */
class __TwigTemplate_429f07a53cb759af005d97690c01f1af1199d788884984a9761f61e4d95bb8bd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "/Events/event.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "/Events/event.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "/Events/event.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo " Event Page ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "
<div class=\"row justify-content-center\">
\t<div class=\"col-lg-6\">
\t\t<img src=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "img", array()), "html", null, true);
        echo "\" alt=\"party\" style=\"border-radius: 40px; width: 100%;\">
\t\t<div class=\"card text-center\">
\t\t  <div class=\"card-header\">
\t\t    ";
        // line 12
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "type", array()), "html", null, true);
        echo "
\t\t  </div>
\t\t  <div class=\"card-body\">
\t\t    <h5 class=\"card-title\">";
        // line 15
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "name", array()), "html", null, true);
        echo "</h5>
\t\t    <p class=\"card-text\">";
        // line 16
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "description", array()), "html", null, true);
        echo "</p>
\t\t    
\t\t    <p class=\"card-text\">";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "email", array()), "html", null, true);
        echo ".</p>
\t\t    <p class=\"card-text\">";
        // line 19
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "address", array()), "html", null, true);
        echo ".</p>
\t\t    <p class=\"card-text\">";
        // line 20
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "telnum", array()), "html", null, true);
        echo ".</p>
\t\t    <a href=\"/Events/editevent/";
        // line 21
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "id", array()), "html", null, true);
        echo "\" class=\"btn btn-success\" title=\"delete\">Edit</a>
\t\t    <a href=\"/Events/delete/";
        // line 22
        echo twig_escape_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "id", array()), "html", null, true);
        echo "\" class=\"btn btn-danger\" title=\"delete\">Delete</a>
\t\t  </div>
\t\t  <div class=\"card-footer text-muted\">
\t\t    <p class=\"card-text\">";
        // line 25
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute(($context["event"] ?? $this->getContext($context, "event")), "eventDate", array()), "F j, Y, g:i a"), "html", null, true);
        echo "</p>
\t\t  </div>
\t\t</div>
\t\t
\t</div>
\t
</div>



";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "/Events/event.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  116 => 25,  110 => 22,  106 => 21,  102 => 20,  98 => 19,  94 => 18,  89 => 16,  85 => 15,  79 => 12,  73 => 9,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block title %} Event Page {% endblock %}

{% block body %}

<div class=\"row justify-content-center\">
\t<div class=\"col-lg-6\">
\t\t<img src=\"{{ event.img }}\" alt=\"party\" style=\"border-radius: 40px; width: 100%;\">
\t\t<div class=\"card text-center\">
\t\t  <div class=\"card-header\">
\t\t    {{ event.type }}
\t\t  </div>
\t\t  <div class=\"card-body\">
\t\t    <h5 class=\"card-title\">{{ event.name }}</h5>
\t\t    <p class=\"card-text\">{{ event.description }}</p>
\t\t    
\t\t    <p class=\"card-text\">{{ event.email }}.</p>
\t\t    <p class=\"card-text\">{{ event.address }}.</p>
\t\t    <p class=\"card-text\">{{ event.telnum }}.</p>
\t\t    <a href=\"/Events/editevent/{{ event.id }}\" class=\"btn btn-success\" title=\"delete\">Edit</a>
\t\t    <a href=\"/Events/delete/{{ event.id }}\" class=\"btn btn-danger\" title=\"delete\">Delete</a>
\t\t  </div>
\t\t  <div class=\"card-footer text-muted\">
\t\t    <p class=\"card-text\">{{ event.eventDate|date('F j, Y, g:i a') }}</p>
\t\t  </div>
\t\t</div>
\t\t
\t</div>
\t
</div>



{% endblock %}", "/Events/event.html.twig", "C:\\xampp\\htdocs\\CodeReview13\\app\\Resources\\views\\Events\\event.html.twig");
    }
}
